create FUNCTION MaximalDistance RETURN NUMBER
IS
    max_year NUMBER;
    min_year NUMBER;
    maximal_distance NUMBER;
BEGIN
    SELECT MAX(PROD_YEAR) INTO max_year FROM MediaItems;
    SELECT MIN(PROD_YEAR) INTO min_year FROM MediaItems;
    maximal_distance := POWER(max_year - min_year, 2);
    RETURN maximal_distance;
END MaximalDistance;
/

