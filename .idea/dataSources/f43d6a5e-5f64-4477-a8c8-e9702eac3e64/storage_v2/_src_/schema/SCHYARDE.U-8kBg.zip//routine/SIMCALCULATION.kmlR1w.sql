create FUNCTION SimCalculation (MID1 NUMBER, MID2 NUMBER, maximal_distance NUMBER) RETURN FLOAT 
IS
	mid1_year NUMBER;
	mid2_year NUMBER;
BEGIN
	SELECT PROD_YEAR INTO mid1_year FROM MediaItems WHERE MID=MID1;
	SELECT PROD_YEAR INTO mid2_year FROM MediaItems WHERE MID=MID2;
    RETURN ( 1 - (  POWER(mid1_year - mid2_year, 2) / maximal_distance) );
END SimCalculation;
/

