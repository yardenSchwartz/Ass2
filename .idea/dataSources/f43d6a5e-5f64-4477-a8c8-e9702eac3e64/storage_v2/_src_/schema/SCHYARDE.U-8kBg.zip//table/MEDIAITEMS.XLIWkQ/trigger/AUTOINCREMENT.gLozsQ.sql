create trigger AUTOINCREMENT
  before insert or update
  on MEDIAITEMS
  for each row
DECLARE
    index_Of_Row NUMBER;
BEGIN
   SELECT COUNT(*) INTO index_Of_Row FROM MediaItems;
    IF index_of_row IS NULL THEN
        :new.MID:=0;
    ELSE
     :new.MID:=index_Of_Row;
    END IF;

   :new.TITLE_LENGTH:=LENGTH(:new.TITLE);
END;
/

